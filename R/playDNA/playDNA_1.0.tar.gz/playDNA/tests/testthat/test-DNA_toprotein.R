describe("codon_info()", {
  it("print informations about a DNA or RNA codon properly", {
    output <- capture.output(codon_info("ATC"))
    expect_true(all(sapply(c("Isoleucine", "I", "ATT, ATC, ATA"), function(p) grepl(p, output))))
    output <- capture.output(codon_info("CUA"))
    expect_match(output, "Leucine (L): CUU, CUC, CUA, CUG, UUA, UUG", fixed = TRUE)
  })
  it("handle incorrect values or empty strings", {
    expect_equal(codon_info("APT8TG"), NULL)
    expect_equal(codon_info(""), NULL)
  })
})

describe("seq_toprotein()", {
  it("handle incorrect values for the parameters or empty strings", {
    expect_equal(seq_toprotein(""), NULL)
    expect_equal(seq_toprotein("ATGTGT89k90aAA"), NULL)
    expect_equal(seq_toprotein("ATGGTACATGAT", 90), NULL)
    expect_equal(seq_toprotein("ATGGTACATGAT", "ciao"), NULL)
    expect_equal(seq_toprotein("ATGGTACATGAT", "ciao"), NULL)
})
  it("handle sequences that are not multiple of 3 by printing an 'X' instead of the corresponding aa", {
    expect_equal(seq_toprotein("ATCGCAA", 3), "Ile-Ala-X")
    expect_equal(seq_toprotein("AA", 3), "X")
  })
  it("compute properly the corresponding protein sequence of DNA and RNA strings", {
    expect_equal(seq_toprotein("ATCGCAGTTCTAAAC", 3), "Ile-Ala-Val-Leu-Asn")
    expect_equal(seq_toprotein("AUCGCGAUUUACGAG", 3), "Ile-Ala-Ile-Tyr-Glu")
    expect_equal(seq_toprotein("AUCGCGAUUUACGAG", 1), "I-A-I-Y-E")
    expect_equal(seq_toprotein("ATCGCAGTTCTAAAC", 1), "I-A-V-L-N")
    expect_equal(seq_toprotein("ATCGCAGTTCTAAAC", "full"), "Isoleucine-Alanine-Valine-Leucine-Asparagine")
  })
})
