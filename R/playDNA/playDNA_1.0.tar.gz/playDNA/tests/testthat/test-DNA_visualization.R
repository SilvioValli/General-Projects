describe("nucleotides_count()", {
  it("handle empty string", {
    expect_equal(nucleotides_count(""), NULL)
  })
  it("correctly output a plot", {
    output <- capture.output(nucleotides_count("ATCATGATGATCATGATC"))
    expect_true(length(output) > 0)
  })
  it("is able to identify DNA and RNA strings", {
    expect_output(nucleotides_count("ATCATGATGATCATGATC"), "DNA")
    expect_output(nucleotides_count("AUCAUGAUGAUCAUGAUC"), "RNA")
  })
  it("Fails if required package is not installed", {
    expect_true(
      requireNamespace("ggplot2", quietly = TRUE),
      info = "The 'ggplot2' package is required but not installed.")
    })
})
