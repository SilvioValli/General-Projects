describe("readDNA()", {
  it("returns NULL when the 'file_path' does not exist",{
    expect_equal(readDNA("blablabla.txt"), NULL)
  })
  it("prints an error when the file contains unexpected characters", {
    temp_file <- tempfile()
    writeLines("ATXGBC6788", temp_file)
    expect_equal(readDNA(temp_file), NULL)
    unlink(temp_file)
})
  it("prints an error when the file is empty", {
    temp_file <- tempfile()
    writeLines("", temp_file)
    expect_equal(readDNA(temp_file), NULL)
    unlink(temp_file)
  })
  it("print 'Upload success!' when the file contains right characters", {
    temp_file <- tempfile()
    writeLines("ATCGTAGTC", temp_file)
    expect_output(readDNA(temp_file), "Upload success!")
    writeLines("AUCGUAGUC", temp_file)
    expect_output(readDNA(temp_file), "Upload success!")
    unlink(temp_file)
  })
  it("check if it is able to handle strings in lowercase", {
    temp_file <- tempfile()
    writeLines("atcgtagtca", temp_file)
    expect_equal(readDNA(temp_file), "ATCGTAGTCA")
    unlink(temp_file)
  })
})
