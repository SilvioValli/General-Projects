describe("transcribe()", {
  it("transcribe a DNA sequence properly", {
    expect_output(transcribe("ATCATCATCGTG"), "AUCAUCAUCGUG")
  })
  it("check for strings with not proper letters", {
    expect_equal(transcribe("ATCTYYYTAG£"), NULL)
  })
  it("check for empty strings", {
    expect_equal(transcribe(""), NULL)
  })
})

describe("complement_reverse()", {
  it("complement and reverse a DNA sequence properly", {
    expect_equal(complement_reverse("ATCATCATCG"), "CGATGATGAT")
  })
  it("complement and reverse a RNA sequence properly", {
    expect_equal(complement_reverse("AUCAUCAUCG"), "CGAUGAUGAU")
  })
  it("check for strings with not proper letters", {
    expect_equal(complement_reverse("AUCAUCAUCGYYYTAPO8"), NULL)
  })
  it("check for strings that are a mix of DNA and RNA", {
    expect_equal(complement_reverse("AUCAUCAUCTGAG"), NULL)
  })
  it("check for empty strings", {
    expect_equal(complement_reverse(""), NULL)
  })
})

describe("GC_content()", {
  it("compute the right CG content of a DNA or RNA string", {
    expect_equal(GC_content("AGCATGCAGTAG"), 0.5)
    expect_equal(GC_content("ATATATATATATA"), 0)
    expect_equal(GC_content("GCGCGCGCGCGCG"), 1)
    expect_equal(GC_content("AGCGCGCGCGCGCG"), 0.93)
  })
  it("handle empty DNA strings", {
    expect_equal(GC_content(""), NULL)
  })
})
