#correct generation
describe("generate_sequence()", {
  it("can generate a random DNA string with a defined length 'len' and type", {
    expect_output(generate_sequence(45, "DNA"), "Generation success!")
  })
  #handle second parameter correctness
  it("print invalid input when type is not 'DNA' or 'RNA' ", {
    expect_error(generate_sequence(34, "ciao"))
  })
  #handle first parameter correctness
  it("print invalid input when len is not a number", {
    expect_error(generate_sequence("ciao", "DNA"))
  })
  #handle empty argument
  it("print invalid input when the arguments are empty", {
    expect_error(generate_sequence(, "DNA"))
    expect_error(generate_sequence(4,))
    expect_error(generate_sequence())
  })
})
