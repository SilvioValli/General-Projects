readDNA <- function(file_path) {
  # Handle file existence
  if (!file.exists(file_path)) {
    cat(paste0("Error: File '", file_path, "' does not exist. Please check the filename.\n"))
    return(NULL)
  }
  # Read the file content and convert to uppercase
  string <- readLines(file_path, warn = FALSE)
  string<- toupper(paste(string, collapse = ""))
  #handle file content different from char
  if (!grepl("^[ATCG]+$", string) && !grepl("^[AUCG]+$", string))  {
    cat(paste0("Error: string content '", string,"' not right. Please check the file content.\n"))
    return(NULL)
  }
  #handle empty dna_string
  if (nchar(trimws(string)) == 0) {
    cat("Error: string empty \n")
    return(NULL)
  }
  cat("Upload success!\n")
  return (string)
}
