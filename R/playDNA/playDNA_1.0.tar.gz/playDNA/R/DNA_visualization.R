#Visualize the nucleotide's frequencies
nucleotides_count <- function(string){
  if (nchar(trimws(string)) == 0) {
    cat("Error: string empty \n")
    return(NULL)}
  U_count <- 0
  T_count <- 0
  if (grepl("U", string)) {
    U_count <- str_count(string, "U")
    cat("RNA")
  } else {
    T_count <- str_count(string, "T")
    cat("DNA")
  }
  #build a df
  df <- data.frame(
    nucleotide_name = c("A", "C", "G", "T", "U"),
    counts = c(str_count(string, "A"),str_count(string, "C"), str_count(string, "G"), T_count, U_count )
  )
  #graph the content
  tryCatch({
    plot <- ggplot(df, aes(x = nucleotide_name, y = counts, fill=nucleotide_name)) +
      geom_col(color = 'black', show.legend = FALSE) +
      scale_y_continuous(breaks = seq(0, max(df$counts)+3, by = 3)) +
      scale_fill_viridis_d() +
      labs(x = "Nucleotides", y = "Count", title = "Nucleotide Content") +
      theme_minimal()
    print(plot)
  },
  error = function(e) {
    cat("An error occurred:", e$message, "\n")
    return(NULL)
  })

}
