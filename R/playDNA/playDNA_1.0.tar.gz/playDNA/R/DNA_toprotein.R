codon_info<-function(x){
  if (!grepl("^[ATCG]+$",x) && !grepl("^[AUCG]+$",x)){
    cat(paste0("Error: codon content '", x,"' not right.\n"))
    return(NULL)
  }
  acids<-c("Isoleucine","Leucine","Valine","Phenylalanine","Methionine","Cysteine","Alanine","Glycine","Proline","Threonine","Serine",
           "Tyrosine","Tryptophan","Glutamine","Asparagine","Histidine","Glutamic acid","Aspartic acid","Lysine","Arginine","Stop codons")
  abb<-c("I","L","V","F","M","C","A","G","P","T","S","Y","W","Q","N","H","E","D","K","R","Stop")
  codon<-c("ATT, ATC, ATA","CTT, CTC, CTA, CTG, TTA, TTG","GTT, GTC, GTA, GTG","TTT, TTC","ATG","TGT, TGC",
           "GCT, GCC, GCA, GCG","GGT, GGC, GGA, GGG","CCT, CCC, CCA, CCG","ACT, ACC, ACA, ACG","TCT, TCC, TCA, TCG, AGT, AGC",
           "TAT, TAC","TGG","CAA, CAG","AAT, AAC","CAT, CAC","GAA, GAG","GAT, GAC","AAA, AAG","CGT, CGC, CGA, CGG, AGA, AGG","TAA, TAG, TGA")
  if (grepl("^[ATCG]+$",x)){
    codon.list<-strsplit(codon,",")
  } else if (grepl("^[AUCG]+$", x)) {
    codon <- gsub("T", "U", codon)
    codon.list<-strsplit(codon,",")
  }

  df <- data.frame(acids=acids[grep(x,codon.list)],abb=abb[grep(x,codon.list)],codons=codon[grep(x,codon.list)])
  cat(paste0(as.character(df$acids)," (",df$abb,"): ", df$codons, "\n"))
}

seq_toprotein <- function(x, len_abbreviation) {
  abb1<-c("I","L","V","F","M","C","A","G","P","T","S","Y","W","Q","N","H","E","D","K","R","Stop")
  abb3<-c("Ile","Leu","Val","Phe","Met","Cys","Ala","Gly","Pro","Thr","Ser","Tyr","Trp","Gln","Asn","His","Glu","Asp","Lys","Arg","Stop")
  full<-c("Isoleucine","Leucine","Valine","Phenylalanine","Methionine","Cysteine","Alanine","Glycine","Proline","Threonine","Serine",
           "Tyrosine","Tryptophan","Glutamine","Asparagine","Histidine","Glutamic acid","Aspartic acid","Lysine","Arginine","Stop codons")
  codon<-c("ATT, ATC, ATA","CTT, CTC, CTA, CTG, TTA, TTG","GTT, GTC, GTA, GTG","TTT, TTC","ATG","TGT, TGC",
           "GCT, GCC, GCA, GCG","GGT, GGC, GGA, GGG","CCT, CCC, CCA, CCG","ACT, ACC, ACA, ACG","TCT, TCC, TCA, TCG, AGT, AGC",
           "TAT, TAC","TGG","CAA, CAG","AAT, AAC","CAT, CAC","GAA, GAG","GAT, GAC","AAA, AAG","CGT, CGC, CGA, CGG, AGA, AGG","TAA, TAG, TGA")
  if (!grepl("^[ATCG]+$",x) && !grepl("^[AUCG]+$",x)){
    cat(paste0("Error: codon content '", x,"' not right.\n"))
    return(NULL)
  }
  if (grepl("^[AUCG]+$",x)){
    codon <- gsub("T", "U", codon)
  }
  rna.list <- str_extract_all(x, ".{1,3}")[[1]]
  protein.list <- list()
  for (rna.codon in rna.list) {
    if (nchar(rna.codon) != 3) {
      protein.list <- append(protein.list,"X")
    } else {
      if (len_abbreviation == 1){
        protein.list <- append(protein.list, abb1[grep(rna.codon, codon)])
      } else if (len_abbreviation == 3) {
        protein.list <- append(protein.list, abb3[grep(rna.codon, codon)])
      } else if (len_abbreviation == "full") {
        protein.list <- append(protein.list, full[grep(rna.codon, codon)])
      } else {
        cat(paste0("Error: 'len_abbreviation' parameter: '", len_abbreviation,"' not right.\n"))
        return(NULL)
      }
    }
    }
  protein.string <- paste( unlist(protein.list), collapse='-')
  return(protein.string)
}

