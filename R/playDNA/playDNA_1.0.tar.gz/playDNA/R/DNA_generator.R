generate_sequence <- function(len, type) {
  # Choose the nucleotide set based on type argument
  if (type == "DNA") {
    nucleotides <- c("A", "T", "C", "G")
  } else if (type == "RNA") {
    nucleotides <- c("A", "C", "U", "G")
  } else {
    stop("Invalid type. Please use either 'DNA' or 'RNA'.")
  }

  if (!is.numeric(len)) {
    stop("Invalid 'len' data type. Please type a valid number (i.e. 35).")
  }

  # Sample 'len' nucleotides with replacement and collapse into a single string
  sequence <- paste(sample(nucleotides, size = len, replace = TRUE), collapse = "")
  cat("Generation success!")
  return(sequence)
}

