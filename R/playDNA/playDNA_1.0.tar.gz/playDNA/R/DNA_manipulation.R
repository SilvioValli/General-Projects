transcribe <- function(string) {
  #check string content
  if (!grepl("^[ATCG]+$", string)) {
    cat(paste0("Error: string content '", string,"' not right.\n"))
    return(NULL)
  }
  transcribed_string <- gsub("T", "U", string)
  cat("Transcribed DNA (mRNA): '", substr(transcribed_string,1,15), "...'\n", sep = '')
  return(transcribed_string)
}

#!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

complement_reverse <- function(string) {
  if (!grepl("^[ATCG]+$", string) && !grepl("^[AUGC]+$", string)) {
    cat(paste0("Error: string content '", string, "' not right.\n"))
    return(NULL)
  }
  # Prevent mixed content: if both T and U appear, it's invalid
  if (grepl("T", string) && grepl("U", string)) {
    cat(paste0("Error: string contains both T and U.\n"))
    return(NULL)
  }

  #handle complement
  if (grepl("T", string)) {
    complement_string <- chartr("ATCG", "TAGC",string)
  } else {
    complement_string <- chartr("AUCG", "UAGC",string)
  }
  #handle reverse
  splits <- strsplit(complement_string, "")[[1]]
  reversed <- rev(splits)
  reversed_complement_string <- paste(rev(strsplit(complement_string, "")[[1]]), collapse = "")
  #cat("Reversed Complement: '", substr(reversed_complement_string,1,15), "...'\n", sep = '')
  return(reversed_complement_string)
}

#!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
#compute the GC content
GC_content <- function(string) {
  #handle empty dna_string
  if (nchar(trimws(string)) == 0) {
    cat("Error: string empty \n")
    return(NULL)}
  G <- str_count(string, "G")
  C <- str_count(string, "C")
  gc_count <-(G+C)/nchar(string)
  return(round(gc_count, 2))
  }




